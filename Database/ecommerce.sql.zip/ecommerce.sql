-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2021 at 04:13 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `email`, `password`, `name`, `mobile`, `created_at`, `updated_at`) VALUES
(3, 'sajibpal20@gmail.com', '154045', 'sajib pal', '01926101829', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(10) UNSIGNED NOT NULL,
  `brand_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_descption` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_name`, `brand_descption`, `brand_status`, `created_at`, `updated_at`) VALUES
(6, 'Samsung', 'mobile', 1, NULL, NULL),
(7, 'Opp', 'Opp mobile', 1, NULL, NULL),
(8, 'Realme', 'Mobile', 1, NULL, NULL),
(9, 'Asus', 'Computer', 1, NULL, NULL),
(10, 'HP', 'computer', 1, NULL, NULL),
(11, 'Infinite', 'sharee', 0, NULL, NULL),
(12, 'Richman', 'T-shirt', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categorys`
--

CREATE TABLE `categorys` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_descption` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categorys`
--

INSERT INTO `categorys` (`id`, `category_name`, `category_descption`, `category_status`, `created_at`, `updated_at`) VALUES
(25, 'Computer', 'Computer device hp ,dell ,asus', 1, NULL, NULL),
(26, 'Mobile', 'Mobile samsung,opp,realme', 1, NULL, NULL),
(27, 'Cloth', 'Coth Tshart,share,', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `logins`
--

CREATE TABLE `logins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2020_11_16_033325_create_admins_table', 1),
(5, '2020_11_21_040040_create_categorys_table', 1),
(6, '2021_04_25_134603_create_logins_table', 1),
(7, '2014_10_12_200000_add_two_factor_columns_to_users_table', 2),
(8, '2019_12_14_000001_create_personal_access_tokens_table', 2),
(9, '2021_04_25_154840_create_sessions_table', 2),
(10, '2021_04_25_191113_crate_posts_table', 3),
(11, '2021_04_27_084135_create_brands_table', 4),
(12, '2021_04_27_205130_create_products_table', 5),
(13, '2021_04_30_194019_create_sliders_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'sajib pal', 'sajibpal20@gmail.com', '258963', NULL, NULL),
(2, 'amit', 'sajibpal20@gmail.com', '223456', NULL, NULL),
(3, 'amit', 'sajibpal20@gmail.com', '25896489', NULL, NULL),
(4, 'amit', 'sajibpal20@gmail.com', '1596485', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(10) UNSIGNED NOT NULL,
  `product_name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `product_short_description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_long_description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` double(8,2) NOT NULL,
  `product_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publication_status` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `category_id`, `brand_id`, `product_short_description`, `product_long_description`, `product_price`, `product_image`, `product_size`, `product_color`, `publication_status`, `created_at`, `updated_at`) VALUES
(4, 'ghh', 9, 2, 'fghfhfh', 'eeeeewrt', 500.00, 'public/imagefile/1619568309.jpg', 'hjk', 'hjkhkk', 1, NULL, NULL),
(5, 'adfd', 11, 4, 'dffgg', 'dhghh', 20.00, 'public/imagefile/1619674019.JPG', 'gf', 'hjj', 1, NULL, NULL),
(8, 'food', 9, 4, 'sd', 'fgh', 200.00, 'public/imagefile/1619809571.jpg', 'large', 'fgjj', 1, NULL, NULL),
(9, 'redmi 9 pro max', 24, 5, 'good', 'best ', 25000.00, 'public/imagefile/1619933826.jpg', 'medium', 'blue', 1, NULL, NULL),
(10, 'SamsungM20', 26, 6, 'no', 'no', 20000.00, 'public/imagefile/1619972320.jpg', 'medium', 'blue', 1, NULL, NULL),
(14, 'Opp', 26, 7, 'no', 'no', 18000.00, 'public/imagefile/1619972608.jpg', 'medium', 'black', 1, NULL, NULL),
(15, 'Realme9', 26, 8, 'no', 'no', 12000.00, 'public/imagefile/1619972674.jpg', 'medium', 'black', 1, NULL, NULL),
(16, 'Asus', 25, 9, 'no', 'no', 50000.00, 'public/imagefile/1619972760.jpg', 'large', 'black', 1, NULL, NULL),
(17, 'T-shirt', 27, 12, 'no', 'no', 300.00, 'public/imagefile/1619973201.jpg', 'large', 'blue', 1, NULL, NULL),
(18, 'T-shirt', 27, 12, 'no', 'no', 400.00, 'public/imagefile/1619973241.jpg', 'medium', 'blue', 1, NULL, NULL),
(20, 'baby dess', 27, 12, 'no', 'no', 600.00, 'public/imagefile/1620028153.jpg', 'small', 'red', 1, NULL, NULL),
(21, 'baby dess', 27, 12, 'no', 'no', 300.00, 'public/imagefile/1620028218.jpg', 'small', 'white', 1, NULL, NULL),
(23, 'baby dess', 27, 12, 'no', 'no', 500.00, 'public/imagefile/1620028336.jpg', 'small', 'blue', 1, NULL, NULL),
(24, 'baby dess', 27, 12, 'no', 'no', 400.00, 'public/imagefile/1620028424.jpg', 'small', 'white', 1, NULL, NULL),
(25, 'Shirt', 27, 12, 'no', 'no', 1500.00, 'public/imagefile/1620028945.jpg', 'large', 'blue', 1, NULL, NULL),
(26, 'Shirt', 27, 12, 'no', 'no', 18000.00, 'public/imagefile/1620028985.jpg', 'medium', 'white', 1, NULL, NULL),
(27, 'Shirt', 27, 12, 'no', 'no', 1500.00, 'public/imagefile/1620029037.jpg', 'large', 'blue', 1, NULL, NULL),
(28, 'T-shirt', 27, 12, 'no', 'no', 400.00, 'public/imagefile/1620135116.jpg', 'large', 'blue', 1, NULL, NULL),
(29, 'T-shirt', 27, 12, 'no', 'no', 350.00, 'public/imagefile/1620135151.jpg', 'medium', 'white', 1, NULL, NULL),
(30, 'hp probook', 25, 10, 'no', 'no', 45000.00, 'public/imagefile/1620135396.jpg', 'medium', 'white', 1, NULL, NULL),
(31, 'hp probook', 25, 10, 'no', 'no', 40000.00, 'public/imagefile/1620135452.jpg', 'medium', 'black', 1, NULL, NULL),
(32, 'hp probook', 25, 10, 'no', 'no', 55000.00, 'public/imagefile/1620135531.jpg', 'medium', 'white', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` int(10) UNSIGNED NOT NULL,
  `slider_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Publication_status` int(25) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `slider_image`, `Publication_status`, `created_at`, `updated_at`) VALUES
(6, 'public/imagefile/1619830279.jpg', 1, NULL, NULL),
(7, 'public/imagefile/1619970286.jpg', 1, NULL, NULL),
(11, 'public/imagefile/1619970547.jpg', 1, NULL, NULL),
(13, 'public/imagefile/1619976913.jpg', 1, NULL, NULL),
(14, 'public/imagefile/1619977113.jpg', 1, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categorys`
--
ALTER TABLE `categorys`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `logins`
--
ALTER TABLE `logins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `logins_email_unique` (`email`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `categorys`
--
ALTER TABLE `categorys`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logins`
--
ALTER TABLE `logins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
